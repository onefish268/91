﻿version="1.19.3"
dependencies={
	"Adorable heart"
}
tags={
	"Sound"
	"Events"
	"Gameplay"
	"Alternative History"
}
picture="thumbnail.png"
name="YSS 起义修复测试版"
supported_version="1.19.3.0"
